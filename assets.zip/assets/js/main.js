/*=============== SHOW MENU ===============*/
const navMenu = document.getElementById('nav--menu'),
    navToggle = document.getElementById('nav--toggle'),
    navClose = document.getElementById('nav--close')
/*=============== MENU SHOW ===============*/
/* Validate if constant exists*/
if (navToggle) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-menu')
    })
}

/*=============== HIDDEN MENU ===============*/
/* Validate if constant exists*/

if (navClose) {
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-menu')
    })
}

/*=============== REMOVE MENU MOBILE ===============*/
const navLink = document.querySelectorAll('.nav__link')

const linkAction = () => {
    const navMenu = document.getElementById('nav--menu')

    navMenu.classList.remove('show--menu')
}
navLink.forEach(n => n.addEventListener('click', linkAction))

/*=============== ADD BLUR TO HEADER ===============*/
const blurHeader = () => {
    const header = document.getElementById('header')
    this.scrollY >= 50 ? header.classList.add('blur-header')
        : header.classList.remove('blur-header')
}

window.addEventListener('scroll', blurHeader)
/*=============== SHOW SCROLL UP ===============*/
const scrollUp = () => {
    const scrollUp = document.getElementById('scroll-up')
    this.scrollY >= 350 ? scrollUp.classList.add('show-scroll')
        : scrollUp.classList.remove('show-scroll')
}
window.addEventListener('scroll', scrollUp)

/*=============== SCROLL SECTIONS ACTIVE LINK ===============*/
const sections = document.querySelectorAll('section[id]')

const scrollActive = () => {
    const scrollY = window.pageYOffset

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight,
            sectionTop = current.offsetTop - 58,
            sectionId = current.getAttribute('id'),
            sectionsClass = document.querySelector('.nav__menu a[href*=' + sectionId + ']')

        if (sectionsClass) {
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                sectionsClass.classList.add('active-link');
            } else {
                sectionsClass.classList.remove('active-link');
            }
        }

    })
}
window.addEventListener('scroll', scrollActive)

/*=============== SCROLL REVEAL ANIMATION ===============*/
const sr = ScrollReveal(
    {
        origin: 'top',
        distance: '60px',
        duration: 2000,
        delay: 100,
    }
)
sr.reveal(`.home__data, .home-card, .explore__data, .explore__user, .footer__container`)
sr.reveal(`.home__card, .card`, { delay: 600, distance: '100px', intrval: 100 })
sr.reveal(`.about__data, .join__image`, { origin: 'right' })
sr.reveal(`.about__image`, { origin: 'left' })
sr.reveal(`.popular__card`, { intrval: 200 })
sr.reveal(`.ebook-container`, { delay: 400, distance: '80px' })
sr.reveal(`.ebook-cover-wrapper`, { origin: 'left', delay: 600 })
sr.reveal(`.ebook-content`, { origin: 'right', delay: 800 })

/*=============== JavaScript to Remove # from URL ===============*/

window.addEventListener("hashchange", function () {
    history.replaceState(null, null, window.location.pathname);
});

/*=============== E-BOOK PURCHASE FUNCTION ===============*/
function buyEbook() {
    // Redirect to Razorpay payment page
    window.open('https://rzp.io/rzp/UGmtA18n', '_blank');
}